<?php 
//  define('HOST','localhost');

//  define('USER','user5');
//  define('PASS','@$^tal1c0m!#%');
//  define('DB','db_mytools');
 
///////////////////////////////////////

 define('HOST','localhost');

 define('USER','root');
 define('PASS','');
 define('DB','db_mytools');
 ?>
