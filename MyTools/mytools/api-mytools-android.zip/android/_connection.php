<?php
$db_host="localhost";
$db_login="root";
$db_password="";
$dbname="db_mytools";
$conn=mysqli_connect($db_host,$db_login,$db_password,$dbname);
?>


